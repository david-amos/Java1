import javax.swing.*;

public class SammysMottoWS {
    public static void main(String[] args){

        System.out.println("ssssssssssssssssssssssssssssssssssssssssss");
        System.out.println("s    sammy's makes it fun in the sun!    s");
        System.out.println("ssssssssssssssssssssssssssssssssssssssssss");


    }
}
