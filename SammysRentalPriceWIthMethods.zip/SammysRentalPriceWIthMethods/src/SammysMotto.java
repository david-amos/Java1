import javax.swing.*;

public class SammysMotto {
    public static void Sammys(){
        System.out.println("ssssssssssssssssssssssssssssssssssssssssss");
        System.out.println("s    sammy's makes it fun in the sun!    s");
        System.out.println("ssssssssssssssssssssssssssssssssssssssssss");
    }
}
